import pandas as pd
import numpy as np
import matplotlib
import plotnine as ggplot
from plotnine import *

import glob
import re

import time

from pandas import DataFrame
from IPython.display import HTML

import sys
sys.path.append("fastai/old/")
#from fastai_v7 import structured

import sys
sys.path.append("fastai/old/")
#from fastai_v7.structured import *
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import Normalizer, OneHotEncoder
import os
import re
import glob
#os.environ["CUDA_VISIBLE_DEVICES"]="7"

from pandas import DataFrame
from IPython.display import HTML

import warnings
warnings.filterwarnings(action='once')
warnings.simplefilter('ignore')


#Load files
filelist_loaded = []
filelist = glob.glob("/home/maghoi/pMHC_data/features5/*.csv"); len(filelist)

for i in range(0, len(filelist)):
    df = pd.read_csv(filelist[i])
    filelist_loaded.append(df)
    
#Extract names
name_list = []
for i in range(len(filelist_loaded)):
    r = re.compile("features5/(.*).csv")
    result = r.search(filelist[i])
    name_list.append(result.group(1))
    
#Functions
def extract_sequence(dfs, i1, i2):
    seq_list = []
    for i in range(len(dfs)):
        seq = dfs[i].Sequence[i1 : i2]
        seq = np.where(seq == "-1", "-", seq)
        seq = "".join(seq)
        seq_list.append(seq)
    return(seq_list)

def extract_4th_col_row(df, axis):
    cols = []
    if axis == 1:
        for i in range(0, df.shape[1], 4):
            cols.append(i)
        return df.iloc[:, cols]
    
    if axis == 0:
        for i in range(0, df.shape[0], 4):
            cols.append(i)
        return df.iloc[cols]
    
from Bio import pairwise2
def pairwise_align_score(seq_list):
    data = np.zeros((366,366))
    for i, p1 in enumerate(seq_list[:]):
        score_list = []

        for p2 in seq_list[:]:
            #p1 = p1.strip("-")
            #p2 = p2.strip("-")

            #Compute similarity
            a = pairwise2.align.globalms(p1, p2, 1, 0, -1, 0)[0][2]
            val = 0
            if len(p1) != len(p2):
                    val = 1
            score = (a+val) / max(len(p1), len(p2))
            score_list.append(score)


        #Append whole row to data
        data[i] = score_list
        if i % 1 == 0:
            print(i, "/", len(seq_list))

    #Create pandas dataframe with correct names
    df = pd.DataFrame(data, index = range(0, 366), columns = range(0, 366))
    return(df)


print("Extracted sequences. length:")
print(len(filelist_loaded[0].Sequence))

print("Extracting sequence")
tcr_list = extract_sequence(filelist_loaded, 192, 468)
print("Extract 3/4 rows")
tcr_list = list(extract_4th_col_row(pd.DataFrame(tcr_list), 0)[0])


int_names = []
for i in range(0, 366, 1):
    int_names.append(str(i))
len(int_names)

print("TCR pairwise align:")
tcr_df = pairwise_align_score(tcr_list)
tcr_df.columns = int_names
tcr_df.index = int_names
tcr_df.to_feather("/home/maghoi/main/data/02_Features/TCR_Matrix.feather")
print("Done")